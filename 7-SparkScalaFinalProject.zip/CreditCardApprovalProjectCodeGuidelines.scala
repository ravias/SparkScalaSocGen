// Credit Card Approval - Code Template
// 
// Use these instructions as a guideline

// Load the datasets into respective dataframes and perform the initial checks

// Check by printing the schema


// Count of records


// See a few records of the dataframe


// Get the list of columns and count of columns to cross-check with the given dataset


// Get descriptions of the coluGetmns
// Especially those that show count less than total records due to missing values


// Check missing values

// Look for the columns that have missing values get the count


// Drop the rows that have null values and verify again

// Read the next input file into a dataframe


// Check by printing the schema


// Count of records


// Show a few records of the second dataframe


// Get the list of columns (column names)


// Get descriptions of the coulmns


// Check for duplicate records in this dataset based on ID column and MONTHS_BALANCE 


// Join the two dataframes on ID column

// Get the count of records in the joined dataframe 


// See the schema of the joined dataframe


// Add a column 'label' and set its value to 0.0 or 1.0 based on the value of the column STATUS
// 
// If value of STATUS is ‘C’, ‘X’, ‘0’, ‘1’ then set label value to 0.0
// 
// For all other values of STATUS set label value to 1.0

// We can consider any record/application as good if the days due is 0 to 60 days
// Any applicaiton/record with more days due than 60 can be labeled as bad 


// Check the schema now and show a fee records


// Transformations

// Bucketizer

// Bucketizer transforms a column of continuous features to a column of feature buckets, where the buckets are specified by users. It takes a parameter:
// 
// splitsArray: Parameter for mapping continuous features into buckets. With n+1 splits, there are n buckets.
// 
// inputCols: CNT_CHILDREN,CNT_FAM_MEMBERS
// 
// outputCol: child_num,family_num
Since 3.0.0, Bucketizer can map multiple columns at once by setting the inputCols parameter.
Note that when both the inputCol and inputCols parameters are set, an Exception will be thrown.
The splits parameter is only used for single column usage, and splitsArray is for multiple columns.
So we can use both the bucketizing tasks in go.
// QuantileDiscretizer

// QuantileDiscretizer takes a column with continuous features and outputs a column with binned categorical features. The number of bins is set by the numBuckets parameter. It is possible that the number of buckets used will be smaller than this value, for example, if there are too few distinct values of the input to create enough distinct quantiles.

// We have 3 columns in the dataset - AMT_INCOME_TOTAL, DAYS_BIRTH, DAYS_EMPLOYED on which we need to apply QuantileDiscretizer and create corresponding binned categorical columns.

// Let us discretize the columns AMT_INCOME_TOTAL, DAYS_BIRTH and DAYS_EMPLOYED

// QuantileDiscretizer bins the records based on AMT_INCOME_TOTAL into 7 bins or 7 buckets.
// 
// Say - 0-very low, 1-low, 2-low medium, 3-medium, 4-high medium, 5-high, 6-very high
// 
// QuantileDiscretizer divides the records based on the range between min and max of AMT_INCOME_TOTAL into the above number of bins and adds and output column specified 'income_category' with the number of the respective bin starting from 0.0 to 6.0 

// Since 3.0.0, QuantileDiscretizer can map multiple columns at once by setting the inputCols parameter. To specify the number of buckets for each column, the numBucketsArray parameter can be set, or if the number of buckets should be the same across columns, numBuckets can be set as a convenience.

// Note that as an alternative, we can convert the column DAYS_BIRTH into years of age by dividing the column by 365, and then use QuantileDiscretizer to create age_group column with corresponding values. Similarly employment duration can be arrived at using the column DAYS_EMPLOYED.

// StringIndexer
StringIndexer encodes a string column of labels to a column of label indices.
StringIndexer can encode multiple columns in Spark 3.x and above.

The indices are in [0, numLabels), and four ordering options are supported:
 - “frequencyDesc”: descending order by label frequency (most frequent label assigned 0)
 - “frequencyAsc”: ascending order by label frequency (least frequent label assigned 0)
 - “alphabetDesc”: descending alphabetical order, and
 - “alphabetAsc”: ascending alphabetical order 
 
default = “frequencyDesc”.
Note that in case of equal frequency when under “frequencyDesc”/”frequencyAsc”, the strings are further sorted by alphabet.We have several string type columns in the dataset. Let us use stringindexer on these and add index columns for each of these which will be numeric type (double).
CODE_GENDER, FLAG_OWN_CAR, FLAG_OWN_REALTY, NAME_INCOME_TYPE, NAME_EDUCATION_TYPE, NAME_FAMILY_STATUS, NAME_HOUSING_TYPE, OCCUPATION_TYPE
// Vector Assembler

// VectorAssembler is a transformer that combines a given list of columns into a single vector column. It is useful for combining raw features and features generated by different feature transformers into a single feature vector, in order to train ML models like logistic regression and decision trees. VectorAssembler accepts the following input column types: all numeric types, boolean type, and vector type. In each row, the values of the input columns will be concatenated into a vector in the specified order.

// Import VectorAssembler from pyspark.ml.feature package

// Create a list of all the variables that you want to create feature vectors
// These features are then further used for training model

// Create the VectorAssembler object


// Spark ML Algorithms

// Split the dataframe into train and test datasets

// Decision Tree

// Decision trees and their ensembles are popular methods for the machine learning tasks of classification and regression.

// Import ml package for decision tree classifier


// Create a decision tree classifier object with variable name being dtc
// Default values of three parameters are as given below.
// dtc = DecisionTreeClassifier(labelCol='label',featuresCol='features',maxBins=32)


// Build the model using the training dataframe using the fit method of the decision tree classifier object


// Apply the model on test dataframe by passing the test dataframe to the transform method of the model


// Check how the dataframe is transformed by the model's transform method
// and note the additional columns added by printing the schema of the predictions dataframe


// Model Evaluation

// To evaluate the model's efficiency import the evaluator library


// Declare the evaluator for the metric accuracy


// Get the accuracy by passing the predictions dataframe to the evaluator 


// ML Pipeline

// Spark MLlib standardizes APIs for machine learning algorithms to make it easier to combine multiple algorithms into a single pipeline, or workflow.
// Let us build the pipeline through which our dataset is passed.

// Building and using the pipeline

// Let us split the dataset in joined dataframe into training and tesing datasets in 70% 30% ratio using randomSplit function

// This is the dataset that will be sent through the pipeline of different algorithms, transformers and estimators


// List the stages of the ML pipeline

// Build the pipeline object that uses the stages listed above


// Fit the data and produce the pipeline model

// Pipeline model is a Transformer that implements a method transform(), which converts one DataFrame into another,
// generally by appending one or more columns.

// Print the schema of the transformed i.e. predicted dataframe

// View the required columns generated


// Pipeline Model Evaluation

// To evaluate the model's efficiency import the evaluator library


// Declare the evaluator for the metric accuracy


// Get the accuracy by passing the predictions dataframe to the evaluator 

