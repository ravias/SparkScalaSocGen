/*
==============================
spark2-shell --master local[*]
==============================
df_from_datasources
====================
*/

import org.apache.spark.sql.SparkSession

val customerDF = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").option("header","true").load("sparkdata/customers.txt")

customerDF.printSchema()
customerDF.select("customer_name").show()
customerDF.select($"customer_id", $"customer_name").show()
customerDF.filter($"customer_state" === "CA").show()
customerDF.groupBy("customer_state").count().show()

customerDF.createOrReplaceTempView("customers")
val cStateCount50 = spark.sql("SELECT customer_state, count(*) as state_count FROM customers GROUP BY customer_state HAVING state_count>=50")

// cStateCount50
cStateCount50.show()
cStateCount50.printSchema()
cStateCount50.count()

cStateCount50.coalesce(1).write.save("cStateOutput1")
// cStateCount50.coalesce(1).write.parquet("cStateOutput2")
// cStateCount50.coalesce(1).write.format("parquet").save("cStateOutput3")

cStateCount50.coalesce(1).write.format("json").save("cStateOutputJSON1")
// cStateCount50.coalesce(1).write.json("cStateOutputJSON2")

// Read and load data in JSON format 

val productDF = spark.read.format("json").load("sparkdata/products.json")
// val productDF2 = spark.read.json("sparkinput/products.json")
productDF.select("product_name").show()
productDF.select($"product_name",$"product_category",$"product_price").show()
productDF.select($"product_name",$"product_category",$"product_price").show(5,false) // To show 5 records without truncation
productDF.filter($"product_price">200.00).show()
productDF.groupBy("product_category").count().show()

productDF.createOrReplaceTempView("products")
val prd200 = spark.sql("SELECT category_id, product_category, count(*) as prdcount FROM products WHERE product_price>200 GROUP BY category_id, product_category ORDER BY product_category")

// prd200
prd200.show()
prd200.printSchema()
prd200.count()

prd200.coalesce(1).write.save("prdOutput1")
// prd200.coalesce(1).write.parquet("prdOutput2")
// prd200.coalesce(1).write.format("parquet").save("prdOutput3")

prd200.coalesce(1).write.format("json").save("prdOutputJSON1")
// prd200.coalesce(1).write.json("prdOutputJSON2")

prd200.coalesce(1).write.format("csv").option("sep", "\t").option("header","true").save("prdOutputCSV1")
// prd200.coalesce(1).write.option("sep", "\t").option("header","true").csv("prdOutputc2")

/*
Now that we have two datasets in two views we can join them on the common column for queries. For example:
Get the list of customers and product categories in which they bought multiple items (quantity) that are more expensive than 200.00
*/
val custlist200 = spark.sql("SELECT a.customer_name, b.product_category, count(*) as prdcount FROM customers a INNER JOIN products b ON a.customer_id=b.customer_id WHERE b.product_price>200.00 GROUP BY a.customer_name, b.product_category HAVING prdcount>1")

val newfmt = spark.sql("SELECT salestxn_id, product_name, (category_id, product_category) as category_details, product_price, product_quantity, customer_id from products")
newfmt.coalesce(1).write.json("newfmtJSON")

