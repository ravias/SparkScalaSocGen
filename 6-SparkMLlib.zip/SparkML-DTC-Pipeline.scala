/*
==============================
spark-shell --master local[*]
==============================
ML Feature related functions and Decision Tree Classification
=============================================================
*/


// Read data

val rawstrokeDF = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("HeartStroke.csv")
rawstrokeDF.printSchema()
rawstrokeDF.show(5, false)
rawstrokeDF.count()

// //// Check missing values
// (For this exercise we will drop all the na values)

import org.apache.spark.sql.functions._

rawstrokeDF.describe().show()

rawstrokeDF.filter($"smoking_history".isNull).count()
rawstrokeDF.filter($"BMI".isNull).count()

// rawstrokeDF.filter(rawstroke("smoking_history").isNull).count()
// rawstrokeDF.filter(rawstroke("BMI").isNull).count()

// rawstrokeDF.filter($"smoking_history".isNull).select(count("*")).show()
// rawstrokeDF.filter($"BMI".isNull).select(count("*")).show()

// The columns "smoking history" and "BMI" has missing values. Let us drop them

// Use df_name.na.drop() to drop all the null values from the dataframe

val rawstrokeDF2 = rawstrokeDF.na.drop()

// Check if the null value still exist
rawstrokeDF2.describe().show()

// Note the count of rows in the dataframe
rawstrokeDF2.count()

// Check the data type of each column

rawstrokeDF2.printSchema()

// The variable values for any supervised ML algorithm has to be of type double. Let us convert the columns "diabetes", "hypertension" and target varaible "stroke" data type into type double

import org.apache.spark.sql.types.DoubleType
val strokeDF = rawstrokeDF2.withColumn("diabetes", col("diabetes").cast("Double")).withColumn("hypertension", col("hypertension").cast("Double"))

strokeDF.printSchema()

// ////// Train-Test Split
// We split the output of  data into training and test sets (30% held out for testing)
// Note: This train-test split of for logistic regression

// We spilt the data into 70-30 set
// Training Set - 70% obesevations
// Testing Set - 30% observations
val Array(trainDF, testDF ) = strokeDF.randomSplit(Array(.7, .3),2020)

trainDF.count()
testDF.count()

// //// Transformations

// //////// Binarizer
// Let us use divide the BMI into two groups: Obese and healthy. 1 represents "obese" and 0 represents "healthy" (If your BMI is 30.0 or higher, it falls within the obese range)
// We will use the Binarizer transformer to create a new variable "Body Type" (1- obese and 0- healthy) by binarizing the "BMI" variable by setting the obesity threshold value 30.0. Binarization is used for thresholding numerical feature to binary feature (0 or 1)

import org.apache.spark.ml.feature.Binarizer

/*
val binarizer: Binarizer = new Binarizer()
  .setInputCol("BMI")
  .setOutputCol("BodyType")
  .setThreshold(30.0)
*/

val binarizer = new Binarizer()
  .setInputCol("BMI")
  .setOutputCol("BodyType")
  .setThreshold(30.0)

// //////// Bucketizer
// We now group the patients based on their age group. Here, we will use the Bucketizer transformer. Bucketizer is used for creating group of values of a continuous feature

import org.apache.spark.ml.feature.Bucketizer

// let us define the age age group splits
val splits = Array(0, 25.0, 50.0, 75.0, 100.0)

val bucketizer = new Bucketizer()
  .setInputCol("age")
  .setOutputCol("ageGroup")
  .setSplits(splits)

// //////// StringIndexer
// There are three categorical variables in our dataset viz., "gender", "heart disease" and "smoking history". These variables cannot be directly passed to our ML algorithms. We will converet them into indexes and to do that we will use StringIndexer transformer. StringIndexer converts a string column to an index column. The most frequent label gets index 0

import org.apache.spark.ml.feature.StringIndexer

val myinputCols = Array("stroke", "gender", "heart_disease", "smoking_history")

val myoutputCols = Array("label", "gender_indexed", "heart_disease_indexed", "smoking_history_indexed")

val indexers = new StringIndexer().setInputCols(myinputCols).setOutputCols(myoutputCols)

/*
Alternatively we can use the following syntax
val indexers = new StringIndexer()
  .setInputCols(Array("stroke", "gender", "heart_disease", "smoking_history"))
  .setOutputCol(Array("label", "gender_indexed", "heart_disease_indexed", "smoking_history_indexed"))
*/

// VectorAssembler
// MLlib expects all features to be contained within a single column. VectorAssembler combines multiple columns and gives single column as output

// Import VectorAssembler from pyspark.ml.feature package

import org.apache.spark.ml.feature.VectorAssembler

// Create a list of all the variables that are required in features vector
// These features are then further used for training model

val features_col = Array("diabetes", "hypertension", "BodyType", "ageGroup", "gender_indexed", "heart_disease_indexed", "smoking_history_indexed")

val assembler = new VectorAssembler().setInputCols(features_col).setOutputCol("features")

/*
Alternatively we can use the following syntax
val assembler = new VectorAssembler()
  .setInputCols(Array("diabetes", "hypertension", "BodyType", "ageGroup", "gender_indexed", "heart_disease_indexed", "smoking_history_indexed"))
  .setOutputCol("features")
*/

// //// Spark ML Algorithms
// We will now train the ML models with the data that we have worked upon so far. We will build classification model since, given the data, we need to determine if a person will get a stroke or not

////// New Stage

// ////// Supervised Learning - Classification 
// //////// Decision Tree

// import the DecisionTree function from the pyspark.ml.classification package

import org.apache.spark.ml.classification.DecisionTreeClassifier

// Build the DecisionTree object "dt" by setting the required parameters
// We will pass the VectorIndexed columns as featureCol for Decision Tree. Since they can handle categorical indexes

val dtc = new DecisionTreeClassifier().setLabelCol("label").setFeaturesCol("features").setMaxDepth(10)

// Building Pipeline

import org.apache.spark.ml.Pipeline

val dtcpipeline = new Pipeline().setStages(Array(binarizer, bucketizer, indexers, assembler, dtc))

val dtcpipelinemodel = dtcpipeline.fit(trainDF)

// transform the test data
val dtcpipelinepredicted = dtcpipelinemodel.transform(testDF)

dtcpipelinepredicted.printSchema()

// view some of the columns generated
dtcpipelinepredicted.select("label", "rawPrediction", "probability", "prediction").show(10)

// Model Evaluation

// import MulticlassClassificationEvaluator from the package
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator

// Build the MulticlassClassificationEvaluator object 'evaluator'
val multievaluator = new MulticlassClassificationEvaluator()
  .setLabelCol("label")
  .setPredictionCol("prediction")
  .setMetricName("accuracy")

val accuracy = multievaluator.evaluate(dtcpipelinepredicted)
println(s"Test Error = ${(1.0 - accuracy)}")

// Model Persistence

// Saving the model
dtcpipelinemodel.write.overwrite().save("saved_dtcpipelinemodel")

import org.apache.spark.ml.PipelineModel

// Load the saved model
val loadeddtcpipelinemodel = PipelineModel.load("saved_dtcpipelinemodel")

// Applying the model on the new records

val newstrokeDF = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("file:///home/unextnovuser022/sparksql/newheartstroke.csv")

val newpredicted = loadeddtcpipelinemodel.transform(newstrokeDF)

newpredicted.printSchema()

// view the relevant of the columns generated
newpredicted.select("rawPrediction", "probability", "prediction").show()
