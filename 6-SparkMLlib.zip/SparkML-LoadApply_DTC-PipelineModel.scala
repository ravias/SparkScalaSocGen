/*
==============================
spark-shell --master local[*]
==============================
ML Feature related functions and Decision Tree Classification
=============================================================
*/

// Read data

val newstrokeDF = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("file:///home/unextnovuser022/sparksql/newheartstroke.csv")
newstrokeDF.printSchema()
newstrokeDF.show(5, false)
newstrokeDF.count()

import org.apache.spark.ml.PipelineModel

// Load the saved model
val loadeddtcpipelinemodel = PipelineModel.load("saved_dtcpipelinemodel")

// Applying the model on the new records

val newpredicted = loadeddtcpipelinemodel.transform(newstrokeDF)

newpredicted.printSchema()

// view the relevant of the columns generated
newpredicted.select("rawPrediction", "probability", "prediction").show()
