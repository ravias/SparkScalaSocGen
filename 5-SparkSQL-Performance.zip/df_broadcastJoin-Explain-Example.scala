/* 
Dataframe Joins and Optimizations
SparkSQL builds in several optimizations while performing joins and other operations on dataframes.

We can check out the execution plan of SparkSQL for any operation using the function "explain()"

When one of the dataframes in the join operation is small enough to fit into a workernode then Spark SQL plans to "broadcast" this dataframe. This is generally referred to as BroadcashJoin. When a dataframe is "broadcasted" then a copy of it is sent to all worker nodes. This avoids shuffling of data when joining it with the larger dataframe as the smaller dataframe is compltely available locally for each partition of the larger dataframe.

The above optimization is done automatically by SparkSQL's built-in optimizer. However we can also check to ensure it is done and in case it is not done it can be done manually also as shown in the example below.

The setting "spark.sql.autoBroadcastJoinThreshold" determines whether a dataframe is small enough to be broadcast or not. The default of this setting is 10 MB (10485760). We can override this when we know that the smaller dataframe is just above this threshold and can be managed to be fit into each worker node.
*/

import org.apache.spark.sql.functions._

import spark.implicits._

// Create DataFrame from data source - csv file

val customerDF = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").load("sparkdata/customers.tsv")
customerDF.printSchema()
customerDF.show(5)
customerDF.count()

val salestxnDF = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").load("sparkinput/salestxns.tsv")
salestxnDF.printSchema()
salestxnDF.show(5)
salestxnDF.count()

// Different types of operations on DataFrames

// val new_names_cDF = Array("customer_id","customer_name","customer_city","customer_state","customer_zipcode")
// val new_names_sDF = Array("salestxn_id", "category_id", "category_name", "product_id", "product_name", "product_price", "product_quantity", "customer_id")

val cDF2=customerDF.toDF("customer_id","customer_name","customer_city","customer_state","customer_zipcode")
val sDF2=salestxnDF.toDF("salestxn_id","category_id","category_name","product_id","product_name","product_price","product_quantity","customer_id")

cDF2.printSchema()
cDF2.show(5)
cDF2.rdd.getNumPartitions
// res2: Int = 1
sDF2.printSchema()
sDF2.show(5)
sDF2.rdd.getNumPartitions
// res3: Int = 4

// Join the two dataframes on customer_id column
val jDF=cDF2.join(sDF2,cDF2("customer_id") === sDF2("customer_id"))
jDF.printSchema()
jDF.count()
jDF.show(5)

// Use explain() function to see the type of join used by Spark SQL
jDF.explain()

// Using explain(true) function gives the outline of the initial logical plans besides the final physical plan used for executing the join operation
jDF.explain(true)

// The function explain() can be used on the dataframe and also on the join operation
// Note that when we use explain() function on the join operaton the join is not performed. Only the plan is explained.

/*
val jDF=cDF2.join(sDF2,cDF2("customer_id") === sDF2("customer_id")).explain()
jDF
jDF.printSchema()
jDF.show(5)

val jDF=cDF2.join(sDF2,cDF2("customer_id") === sDF2("customer_id")).explain(true)
jDF
jDF.printSchema()
jDF.show(5)
*/

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

// By setting this value to -1 broadcasting can be disabled.
spark.conf.set("spark.sql.autoBroadcastJoinThreshold","-1")

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

val jDF1=cDF2.join(sDF2,cDF2("customer_id") === sDF2("customer_id"))

jDF1.explain()
jDF1.explain(true)

// We can notice that broadcast join is not used now as the threshold is disabled.

jDF1.printSchema()
jDF1.show(5)

// Using the join operation by interchanging the dataframes from left to right.
/*
val jDF2=sDF2.join(cDF2,sDF2("customer_id") === cDF2("customer_id"))
jDF2.explain()
jDF2.explain(True)

jDF2.printSchema()
jDF2.show(5)
*/

// The lines below show how to mark a dataframe for broadcast in case required to be done manually.
val jDF3=sDF2.join(broadcast(cDF2),sDF2("customer_id") === cDF2("customer_id"))
jDF3.explain()
jDF3.explain(true)

// Now we will see that broadcast join is used for the join by broadcasting customer DF which has been specified in the above line for broadcast

jDF3.printSchema()
jDF3.show(5)

// The lines below show the same with customer DF on the left side of the join

val jDF4=broadcast(cDF2).join(sDF2,cDF2("customer_id") === sDF2("customer_id"))
jDF4.explain(true)
jDF4.explain()

// Now we will see that broadcast join is used for the join by broadcasting customer DF which has been specified in the above line for broadcast

jDF4.printSchema()
jDF4.show(5)

// Using "hint" function to broadcast the smaller dataframe
val jDF5=sDF2.join(cDF2.hint("broadcast"),sDF2("customer_id") === cDF2("customer_id"), "inner"))
jDF5.explain()

//  //  //  //  //

sDF2.cache()

sDF2.count()

val jDF6=broadcast(cDF2).join(sDF2,cDF2("customer_id") === sDF2("customer_id"))

jDF6.count()

/*
In the physical plan below we can see "InMemoryTableScan" being used for both the dataframes which is not the case in the previous one.
This means that the data is read from the cache() instead of re-building the dataframes from scratch.
*/

jDF6.explain()

jDF6.show(5)

/*
In the statement below, after join we are doing a filter and also we are doing select of only 5 columns.
In the physical plan shown after the explain statement, we can see projection (select clause) push and filter push.
This means that the query execution engine executes projection and then filter and only after that join is executed, which is more optimal way of executing the whole statement.
*/

val jDF7=cDF2.hint("broadcast").join(sDF2,cDF2("customer_id") === sDF2("customer_id")).select("customer_name","customer_city","product_name","product_price","product_quantity").where(cDF2("customer_state")==="IL")

jDF7.show(5)

jDF7.explain()