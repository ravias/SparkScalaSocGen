/*
==============================
spark2-shell --master local[*]
==============================
Persist Demo-2
====================
*/

val lines = sc.textFile("sparkinput/war_and_peace.txt",3)

lines.persist()
lines.count()

val nonNullLines = lines.filter(line => line.length>0)
val words = nonNullLines.flatMap(line => line.split(" ") )

words.count()
/*
res2: Long = 562705
*/

val upperWords = words.map(word => word.toUpperCase)
val pairedOnes = upperWords.map(uw => (uw, 1))
val wordCounts = pairedOnes.reduceByKey(_ + _)
wordCounts.count()
// wordCounts.take(5)
// wordCounts.take(5).foreach(println)

// val wordCounts = pairedOnes.reduceByKey( (x, y) => x + y)
