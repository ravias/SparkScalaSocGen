/*
==============================
spark2-shell --master local[*]
==============================
Persist Demo-1
====================
*/

val lines = sc.textFile("sparkinput/war_and_peace.txt",3)
lines.count()
// lines.take(5)

val nonNullLines = lines.filter(line => line.length>0)
val words = nonNullLines.flatMap(line => line.split(" ") )
words.count()
// words.take(5)

/*
 ERROR executor.Executor: Exception in task 1.0 in stage 1.0 (TID 4)
java.io.FileNotFoundException: File does not exist: /user/Ravi/sparkinput/war_and_peace.txt
        at org.apache.hadoop.hdfs.server.namenode.INodeFile.valueOf(INodeFile.java:66)
        at org.apache.hadoop.hdfs.server.namenode.INodeFile.valueOf(INodeFile.java:56)
*/

val upperWords = words.map(word => word.toUpperCase)
val pairedOnes = upperWords.map(uw => (uw, 1))
val wordCounts = pairedOnes.reduceByKey(_ + _)
wordCounts.count()
// wordCounts.take(5)
// wordCounts.take(5).foreach(println)

// val wordCounts = pairedOnes.reduceByKey( (x, y) => x + y)
