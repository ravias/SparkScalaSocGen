# Prior to runningthis application
# Create a directory named "streamingdata" in local file system home directory i.e. /home/YourLoginid
# To simulate streaming data use file transfer protal and upload the files data1.csv etc one by one
# groupby operation will start and the result will be displayed as soon as a file is transferred

#Structured Streaming Example

# Run spark shell using the command
# spark-shell --master local[*]

# Import the necessary classes
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StructType,StructField,StringType,IntegerType,DoubleType}

# creating Schema
# structured Streaming proccesing always requires the specification of a schema for the data in the stream

val schema = StructType(Array(
    StructField("emp_id", IntegerType, true),
    StructField("emp_name", StringType, true),
    StructField("job_name", StringType, true),
    StructField("manager_id", IntegerType, true),
    StructField("salary", DoubleType, true),
    StructField("dept_name", StringType, true)
   ))

# creating Streaming Dataframe that would read the data from a given folder

val employee = spark.readStream.schema(schema).option("header", true).option("sep", ",").csv("file:///home/march14ap011/streamingdata/")

# query to find the total count of employees in a particular profession
employee.groupBy("job_name").count().writeStream.format("console").outputMode("complete").start().awaitTermination()

# Now you will notice the groupby operation is run by spark on the existing data and result gets displayed

# The next file from data?.csv gets transferred to the above directory
# The groupby computation will get started again by spark structured streaming and the result including the previous data is displayed again.

# Each time a file is transferred, the stream is read and the computation is performed.
# Since we specified output mode as complete the complete data is taken for the computation i.e. the group by aggregation.
# You can terminate the session with Control+C