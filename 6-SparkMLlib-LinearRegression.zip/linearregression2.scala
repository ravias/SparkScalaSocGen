/*
==============================
spark2-shell --master local[*]
==============================
linear regression 3
====================
*/

import org.apache.spark.sql.SparkSession

import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.feature.StandardScaler

val data = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("sparkdata/linregdata1.csv")
data.printSchema()

val lr_data = data.select(col("energy_output").alias("label"), col("temperature"), col("exhaust_vacuum"), col("ambient_pressure"), col("relative_humidity"))
lr_data.printSchema()
lr_data.show()

val Array(training, test) = lr_data.randomSplit(Array(.7, .3))

// val vectorAssembler = new VectorAssembler().setInputCols(Array("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity")).setOutputCol("unscaled_features")

val features = Array("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity")
val vectorAssembler = new VectorAssembler().setInputCols(features).setOutputCol("unscaled_features")

val standardScaler = new StandardScaler().setInputCol("unscaled_features").setOutputCol("features")

val lr = new LinearRegression().setMaxIter(10).setRegParam(0.1)

val pipeline = new Pipeline().setStages(Array(vectorAssembler, standardScaler, lr))

val model = pipeline.fit(training)

val prediction_df = model.transform(test)

prediction_df.show(false)
prediction_df.select("label","prediction").show(false)

import org.apache.spark.ml.evaluation.RegressionEvaluator

val eval = new RegressionEvaluator().setLabelCol("label").setPredictionCol("prediction").setMetricName("rmse")

val rmse = eval.evaluate(prediction_df)
val mse = eval.setMetricName("mse").evaluate(prediction_df)
val mae = eval.setMetricName("mae").evaluate(prediction_df)
val r2 = eval.setMetricName("r2").evaluate(prediction_df)

// // // 
// Saving the model
model.write.overwrite().save("saved_model2")

import org.apache.spark.ml.PipelineModel

// Load the saved model
val loaded_model = LinearRegressionModel.load("saved_model2")

// Applying the model on the new records

val newlinreg_df = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("file:///home/unextnovuser022/sparksql/newlinreg.csv")
newlinreg_df.show()

val newprediction_df = loaded_model.transform(newlinreg_df)

newprediction_df.printSchema()

newprediction_df.show()
newprediction_df.select("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity", "prediction").show()
