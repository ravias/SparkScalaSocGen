// spark2-shell --master local[*]

val airportDF = spark.read.format("csv").option("inferSchema", "true").option("header","true").load("sparkdata/airportdata.csv")
val flightDF = spark.read.format("csv").option("inferSchema", "true").option("header","true").load("sparkdata/flightdata.csv")

airportDF.count()
flightDF.count()

// Check the schema of the dataframe. Specifically look for airTime and arrivalDelay columns of flight data
airportDF.printSchema()
flightDF.printSchema()

airportDF.show(5,false)
flightDF.show(5,false)

// Check the data description i.e. stats of all columns
airportDF.describe().show()
flightDF.describe().show()

// For a specific column the stats can be checked as below
flightDF.describe("distance").show()

// 1.	Check the schema of the data frame after having flight data. The columns airtime and arrivalDelay would be inferred as string. This is because some of the rows have �NA� in these columns. Remove these rows using filter function and cast these columns to integer.

val flightDF2=flightDF.where(col("airTime") =!= "NA").withColumn("airTime",col("airTime").cast("Integer")).withColumn("arrivalDelay",col("arrivalDelay").cast("Integer"))

flightDF2.count()
// Now check and compare the data type of airTime and arrivalDelay columns
flightDF2.printSchema()

// 2.	As some of the reports require month-wise breakup of flight data, add a column with the number of the month and another column with the name of the month extracted from the date column.

//Add a column start_to_date by converting startDate column from string to date

val flightDF3=flightDF2.withColumn("start_to_date",(to_date(col("startDate"), "MM/dd/yyyy")))
flightDF3.printSchema()
flightDF3.show()

// Example date functions
flightDF3.select( col("start_to_date"), year(col("start_to_date")).as("year"), 
       month(col("start_to_date")).as("month"), 
//       dayofweek(col("start_to_date")).as("dayofweek"), 
       date_format(to_date($"start_to_date"), "u").as("dayofweek_num"),
       date_format(to_date($"start_to_date"), "EEEE").as("dayofweek"),
       dayofmonth(col("start_to_date")).as("dayofmonth"), 
       dayofyear(col("start_to_date")).as("dayofyear"), 
       next_day(col("start_to_date"),"Sunday").as("next_day"), 
       weekofyear(col("start_to_date")).as("weekofyear") 
   ).show()

val flightDF4 = flightDF3.withColumn("month",(month(col("start_to_date"))))
flightDF4.printSchema()
flightDF4.show()


// 3.	In the flight data, add a new column cancellationReason and populate it as per the following conditions.
// 1 - Carrier
// 2 - Weather
// 3 - NAS
// 4 - Security

// Using when & otherwise function
val flightDF5=flightDF4.withColumn("cancelReason", when( col("cancellationCode").equalTo(1),lit("carrier")).when( col("cancellationCode").equalTo(2),lit("weather")).when( col("cancellationCode").equalTo(3),lit("NAS")).when( col("cancellationCode").equalTo(4),lit("security")).otherwise(col("cancellationCode")) )
flightDF5.printSchema()
flightDF5.show()

// Using a Map and .na.replace function contents of the existing column can be replaced with new values
// This will not add a new column. It uses the existing column and replaces the values
val ccmap=Map("1" -> "carrier", "2" -> "weather", "3" -> "NAS", "4" -> "security")
val flightDF5A=flightDF4.withColumn("cancellationCode",col("cancellationCode").cast("String")).na.replace("cancellationCode",ccmap)
flightDF5A.printSchema()
flightDF5A.show()

// 4. As some of the reports require airport names to be provided, add the columns of the airport data by join.
// Join is done with airport data on airport code and origin code once and the on airport code and destination code

val flightDF6 = flightDF5.join(airportDF,flightDF5("origin")===airportDF("code"), "inner").withColumnRenamed("code","originCode").withColumnRenamed("name","originName").withColumnRenamed("areaCode","originAreaCode")
flightDF6.printSchema()
flightDF6.show()

val flightDF7 = flightDF6.join(airportDF,flightDF6("destination")===airportDF("code"), "inner").withColumnRenamed("code","destCode").withColumnRenamed("name","destName").withColumnRenamed("areaCode","destAreaCode")
flightDF7.printSchema()
flightDF7.show()

// This completes the pre-processing of the data.
// We should be able to generate the reports from this dataframe.

// 5. Give the breakup of number of cancellations based on origin airport. Which origin airport had maximum cancellations? Airport names should be mentioned in the list in addition to the airport code.
flightDF7.filter(col("cancelled")===1).count() // to verify total count
flightDF7.filter(col("cancelled")===1).groupBy("originName").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc).show()
val fDF8=flightDF7.filter(col("cancelled")===1).groupBy("originName").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc)
// Save the result into a Hive table or a CSV file as required

// 6. Give reason-wise breakup of cancellations. What is the reason recorded for maximum number of cancellations?
flightDF7.filter(col("cancelled")===1).groupBy("cancelReason").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc).show()
val fDF9=flightDF7.filter(col("cancelled")===1).groupBy("cancelReason").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc)
// Save the result into a Hive table or a CSV file as required

// 7. Give month-wise breakup of cancellations from the available data. Which month has maximum number of cancellations?
flightDF7.filter(col("cancelled")===1).groupBy("month").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc).show()
val fDF10=flightDF7.filter(col("cancelled")===1).groupBy("month").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc)

// 8. Give the breakup of number of diversions based on destination airport. Which destination airport caused maximum diversions? Airport names should be mentioned in the list in addition to the airport code.
flightDF7.filter(col("diverted")==="Yes").count() // to verify total count
flightDF7.filter(col("diverted")==="Yes").groupBy("destName").agg(count("diverted").as("divert_count")).orderBy(col("divert_count").desc).show(false)
val fDF11= flightDF7.filter(col("diverted")==="Yes").groupBy("destName").agg(count("diverted").as("divert_count")).orderBy(col("divert_count").desc)
// Save the result into a Hive table or a CSV file as required

// 9. Give month-wise breakup of diversions from the available data. Which month has maximum number of diversions?
flightDF7.filter(col("diverted")==="Yes").groupBy("month").agg(count("diverted").as("divert_count")).orderBy(col("divert_count").desc).show(false)
val fDF12=flightDF7.filter(col("diverted")==="Yes").groupBy("month").agg(count("diverted").as("divert_count")).orderBy(col("divert_count").desc)
// Save the result into a Hive table or a CSV file as required

// 10. Provide a listing giving the number of flights that arrived ahead of the scheduled time, flights that arrived on time and the flights that arrived late.
flightDF7.filter(col("arrivalDelay")<0).count()
flightDF7.filter(col("arrivalDelay")<0).agg(sum("arrivedAhead").as("arrivedAheadCount")).show()
flightDF7.filter(col("arrivalDelay")===0).count()
flightDF7.filter(col("arrivalDelay")===0).agg(count("arrivalDelay").as("arrivedOnTime")).show()
flightDF7.filter(col("arrivalDelay")>0).count()
flightDF7.filter(col("arrivalDelay")>0).agg(count("arrivalDelay").as("arrivedLate")).show()

val fDF13=flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 ))
fDF13.show()
fDF13.printSchema()

fDF13.agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
).show()

val fDF13A= fDF13.agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF13A.show()
fDF13A.printSchema()

flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
).show()

val fDF13B=flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF13B.show(5,false)
fDF13B.printSchema()


// 11. Generate the above list for flights that have been diverted.
val fDF14=flightDF7.filter(col("diverted")==="Yes").
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF14.show(5,false)
fDF14.printSchema()

// 12. Generate the above list for flights that have not been diverted.
val fDF15=flightDF7.filter(col("diverted")==="No").
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF15.show(5,false)
fDF15.printSchema()

// 13. Provide a listing giving the destination airport-wise breakup of number of flights that arrived ahead of time. Airport names should be mentioned in the list in addition to the airport code.

// 14. Provide a listing giving the destination airport-wise breakup of number of flights that arrived on time. Airport names should be mentioned in the list in addition to the airport code.

// 15. Provide a listing giving the destination airport-wise breakup of number of flights that arrived late. Airport names should be mentioned in the list in addition to the airport code.
